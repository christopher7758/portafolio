<?php
  /* 
  * Clase para registrar ya con uso del modelo este paso es el final obtendremos una arreglo 
  * de datos que nos encargaremos de meter a la base de datos de forma segura y previniendo
  * inyecciones SQL 
  */

  class SignUpModel extends link{
    
    protected $conexion;
     # Inicializa una conexion y la guarda dentro del atributo $conexion
    public function __construct()
    {
      $link = link::__db(user, pass, dbname);
      $this->conexion = $link;
    }
     # Insercion de datos por parte del modelo
     
    public function CheckFields($data)
    {
       # Llamamos al atributo conexion para hacer operaciones con la base de datos
      $link = $this->conexion;
       # Creamos una sentencia SQL que verifique los datos almacenados en la base de datos
      $SQL = "SELECT usuario, correo 
              FROM ".table." 
              WHERE (usuario = :usuario OR correo = :correo)";
       # Instanciamos el statament para insertar datos mediante PDO 
      $stmt = $link->prepare($SQL);
        
      /* 
      * Agregamos parametros a la sentencia SQL remplazando el :variable
      * por una valor del array que nos pasaron en la funcion
      */
      $stmt->bindParam(':usuario',$data['user'], PDO::PARAM_STR);
      $stmt->bindParam(':correo', $data['mail'], PDO::PARAM_STR);
      $stmt->execute(); //Ejecutamos la consulta SQL
      /* 
      * Vamos a evaluar si se ejecuto la sentecia SQL y si el resultado de la consulta
      * arrojo mas de 0 filas y ejecutamos una accion en dado caso
      */
      if( $stmt->rowCount() > 0 ){
        # Usuario o correo no disponibles
        $response = "not available";
      }else{
        # Correo y usuario disponibles!!!
        $response = "available";
      }

      # Regresamos la respuesta al controlador segun el resultado de la condicional
      return $response;
    }
      
    public function Add_record($data)
    {
      # Instanciamos la conexion a base de datos
      $link = $this->conexion;
      # Creamos consulta SQL para insertar datos en la base de datos
      $SQL = "INSERT INTO ".
            table." (nombre, apellido, usuario, correo, secret_pass, edad) 
            VALUES (:nombre, :apellido, :usuario, :correo, :secret_pass, :edad)";
      /* 
      * Creamos una estancia de PDO y empezamos a modificar la sentencia SQL
      * asignando variables de el arreglo data a la sentencia mediante
      * bindParam()
      */
      $stmt = $link->prepare($SQL);
      $stmt->bindParam(":nombre", $data["name"], PDO::PARAM_STR);
      $stmt->bindParam(":apellido", $data["last"], PDO::PARAM_STR);
      $stmt->bindParam(":usuario", $data["user"], PDO::PARAM_STR);
      $stmt->bindParam(":correo", $data["mail"], PDO::PARAM_STR);
      $stmt->bindParam(":secret_pass", $data["pass"], PDO::PARAM_STR);
      $stmt->bindParam(":edad", $data["edad"], PDO::PARAM_STR);

      # Evaluamos si la consulta se ejecuto en TRUE o False
      if($stmt->execute()){
        #registro comleto
        $response = "Complete";
      }else{
        #registro fallido problemas internos
        $response = "FAILED";
      }
      # Damos una respuesta al controlador
      return $response;
    }
  }