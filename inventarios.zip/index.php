<?php
  /* 
   * Vamos a capturar si el usuario a iniciado sesion y si fue asi lo redegiremos al
   * panel de control o el dashboard de lo contrario vamos a incluir una vista y los
   * elementos necesarios para un inicio de la aplicacion correcta
  */
  if(isset($_SESSION['login'])){
    header('Location: views/dashboard.php');
    exit;
  }else{
   # Archivos necesarios para incluir una vista y otros elementos
    require "config/constans.php";
    require "views/templated/layaout.php";
    require "views/templated/header.php";
  }
?>
  
  <h1>
    soy el index :)
  </h1>
</body>
</html>



