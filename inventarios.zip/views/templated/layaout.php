<!--
  Aplicacion creadata totalmente por christopher
  Contacto: christophergerardy778@gmail.com
  Rama de desarollo: Backend
  Conocimientos: Mysql, PHP, Javascript, HTML, CSS
  Frameworks que utilizo: Laravel
  Librerias: Jquery
  Vercion del sitio web: MACH 2.0.5
-->
<!DOCTYPE html>
<html lang="en">
<head>
    <title><?= app ?></title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/normalize/8.0.0/normalize.min.css">
</head>
<body>
