<header>
  <nav>
    <div class="menu">
      <ul>
        <li><a href="sign_up.php">Registrate</a></li>
        <li><a href="">Iniciar sesion</a></li>
      </ul>
    </div>
  </nav>
</header>