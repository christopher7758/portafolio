<?php
  /* 
  * Clase exclusiva para obtener datos de formularios de la aplicacion
  * Metodo que obtiene datos
  * Metodo que obtiene contraseñas
  * Metodo que obtiene variables de la url por si es necesaria mas adelante
  */

  class __data{
    
    public function __getdata($value)
    {
      $data = strtolower( $_POST[ $value ] );
      return $data;
    }

    public function __getpassword($pass)
    {
      $hash = password_hash( $_POST[ $pass ], PASSWORD_DEFAULT);
      return $hash;
    }
  
  }