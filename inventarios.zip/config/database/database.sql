CREATE TABLE `id5341384_portafolio`.`id_5341384_application`(
    `id` INT(10) NOT NULL AUTO_INCREMENT,
    `nombre` VARCHAR(15) NOT NULL,
    `apellido` VARCHAR(15) NOT NULL,
    `usuario` VARCHAR(10) NOT NULL,
    `correo` TEXT NOT NULL,
    `secret_pass` VARCHAR(80) NOT NULL,
    `edad` INT(3) NOT NULL,
    PRIMARY KEY(`id`)
) ENGINE = InnoDB;