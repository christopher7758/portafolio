<?php
  /* 
  * Constantes de aplicacion estas se modifican en caso de que la aplicacion cambie de nombre
  * o sufra algun cambio mayor de logica como los datos de conexion a bases de datos o
  * modificacion en algun elemento en especifico de la vista que se muestre y aparezca aqui
  */


  /*---------------------------------------------------------------------- 
  | Nombre de constantes con respecto a datos vitales de la aplicacion
  |-----------------------------------------------------------------------
  | nombre de la app
  | usuario de base de datos
  | contraseña base de datos
  | nombre de base de datos
  | nombre de la tabla
  |-----------------------------------------------------------------------
  */

  # Nombre de la aplicacion
  define('app', 'Dataspace');
  # Usuario de base de datos
  define('user', 'id5341384_chris_0602');
  # contraseña base de datos
  define('pass', 'GEO699');
  # nombre base de datos
  define('dbname', 'id5341384_portafolio');
  # nombre de la tabla en base de datos
  define('table', 'id_5341384_application');

  

