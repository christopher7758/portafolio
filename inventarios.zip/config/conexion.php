<?php
  /* 
  * Conexion a base de datos con las constantes que se declararon en el archivo constants.php
  * usaremos estos datos de conexion para no incluirlos de forma plana en el archivo y tener
  * mejor seguridad
  */
  class link{

    protected $conexion;

    public function __db($user, $pass, $database)
    {
      try{    
          $conexion = new PDO(
            "mysql:host=localhost;dbname=$database",
            $user,
            $pass,
            array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8")
          );
        }catch( PDOException $Ex ) {
            echo $Ex->getMessage();
        }
        #Regresa la conexion a base de datos
        return $conexion;
    }
  }
  