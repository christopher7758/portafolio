$(document).ready(function () {
  /* 
  * Desactivo que el formulario me redirija o recargue la pagina
  * al activar el evento submit
  */
  $('.button').on('click', function (evento) {  
    evento.preventDefault();
    /* 
    * Recojo los datos que ingreso el usuario en el formulario
    */
    var datos = $('form').serialize();

    // Inicio Ajax y sus metodos y propiedades
    $.ajax({
      /* 
      * Propiedades tipo JSON de ajax
      * tipo de peticion
      * url de destino
      * datos a enviar
      */
      type: "POST",
      url: "./src/Registrar.php",
      data: datos,
      // Funcion que se ejecuta antes de enviar el formulario
      beforeSend: function() {
        console.log("funciona!!");
      },
      // la funcion success es aquella que se ejecuta al ultimo
      success: function (response) {
        /* 
        * Vamos a evaluar la respuesta del servidor que nos retornara desde mi archivo PHP
        */

       switch(response) {
        case "100":
            $(".output").text("usuario o correo registrados");
            break;
        case "404":
            $(".output").text("usuario o correo registrados");
            break;
        case "150":
            $(".output").text("Llene todos los campos");
            break;
        case "200":
            location.href = "views/dashboard.php";
            break;
        default:
            console.log(typeof(response)+ response);
        }
      }
    })
  });
});