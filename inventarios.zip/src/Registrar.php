<?php
  /* 
  * Medio por el cual llamaremos un controlador para ejecutar una accion
  * la carpeta Source ejecuta las acciones dictadas por el controlador
  * de esta forma no damos indicios de existencia de la carpeta controllers
  * evitando algunas brechas de seguridad
  */

   # Comprobaremos si el usuario ah hecho click sobre l boton para guardar datos
  if(isset($_POST['access'])){
    require '../controllers/SignUpController.php';
   # Logica de la app llamamos al controlador y ejecutamos los metodos necesarios
    $registro = new SignUpController;
    $registro->process();

  }else{
    header('Location:../sign_up.php');
    exit;
  }
