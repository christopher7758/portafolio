<?php
  /* 
  * Controlador de registro de usuarios este controlador tiene de tarea el 
  * obtener datos y prosesarlos por medio de metodos de la clase __data
  * que nos regresara los datos y la guardaremos en una variable.
  */
  
  # Requerimos la clase __data
  require '../config/__data.php';
  # Requerimos las constantes
  require '../config/constans.php';
  # Requerimos la conexion a base de datos
  require '../config/conexion.php';
  # Requerimos el modelo
  require '../models/SignUpModel.php';
  /* 
  * Vamos a prosesar los datos:
  * ver que no este vacios
  * convertirlos a un array
  * convertirlos a minuscula
  * pasarlo a un modelo
  */
  class SignUpController extends __data{
    
    public function process()
    {
     # Obtenemos los datos del formulario
      $nombre =   __data::__getdata('nombre');
      $apellido = __data::__getdata('apellido');
      $usuario =  __data::__getdata('usuario');
      $correo =   __data::__getdata('correo');
      $password = __data::__getpassword('password');
      $edad =     __data::__getdata('edad');
     #Comprobamos que ningun dato este vacio
      if(
        empty($nombre) || empty($apellido) || empty($usuario) ||
        empty($correo) || empty($password) || empty($edad)){
       # Ejecutamos una accion si el usuario dejo campos vacios
       echo "150";
       exit;
      }else{
       # Convertiremos los datos en un array asociativo que pasaremos a un modelo
        $data = array(
          "name" => $nombre,
          "last" => $apellido,
          "user" => $usuario,
          "mail" => $correo,
          "pass" => $password,
          "edad" => $edad
        );
        # Instanciamos el modelo para registrar datos
        $modelo = new SignUpModel;
        # Guardamos la respuesta del modelo en una variable
        $accion = $modelo->CheckFields($data);
        /* 
        * Evaluamos la respuesta del modelo y hacemos una accion segun
        * sea la respuesta que nos dio el modelo
        */
        if($accion == "available"){
          # Llamamos un metodo del modelo para registrar los datos y lo guardamos en una 
          # variable
          $res = $modelo->Add_record($data);
        
          if($res == "Complete"){ // Evaluamos la respuesta que nos de el modelo
            # Creamos una session y lo redirigemos al panel de la aplicacion
            session_start();
            //Sesion con el nombre del usuario
            $_SESSION["login"] = $data["user"];
            //Lo mandamos al panel por medio de ajax
            echo 200;
            exit; //Evitamos que se ejecute mas codigo 
          }else{
            /*
            * Error donde la culpa fue del operador o nececitamos una vercion de php
            * reciente y quedo obsoleta o el host no tiene soporte con PDO
            */
            echo 404;
            exit;
          }
        }else{
          # Mensaje de error de que el usuario o correo estan en uso
          echo 100;
          exit;
        }
      }
    }
  }