<?php
  /* 
   * Vamos a capturar si el usuario a iniciado sesion y si fue asi lo redegiremos al
   * panel de control o el dashboard de lo contrario vamos a incluir una vista y los
   * elementos necesarios para un inicio de la aplicacion correcta
  */
  if(isset($_SESSION['login'])){
    header('Location: views/dashboard.php');
    exit;
  }else{
   # Archivos necesarios para incluir una vista y otros elementos
    require "config/constans.php";
    require "views/templated/layaout.php";
    require "views/templated/header.php";
  }
?>
  <div class="response"></div>
  <form action="./src/Registrar.php" method="POST">
    <label>Nombre
      <input type="text" name="nombre" required="true" minlength="4" maxlength="15">
    </label>

    <label>Apellido
      <input type="text" name="apellido" required="true" minlength="4" maxlength="15">
    </label>

    <label>Usuario
      <input type="text" name="usuario" required="true" minlength="6" maxlength="10">
    </label>

    <label>Correo
      <input type="email" name="correo" required="true" maxlength="70">
    </label>

    <label>Contraseña
      <input type="password" name="password" required="true" minlength="6" maxlength="20">
    </label>

    <label>Edad
      <input type="number" name="edad" required="true" maxlength="2">
    </label>

    <input type="hidden" name="access">

    <input type="submit" name="formulario" value="Guardar" class="button">
  </form>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="public/js/new_register.js"></script>
  <?php include "views/templated/footer.php" ?>
</body>
</html>